Copyright (c) 2013 Jasper Reddin
All rights Reserved

The developer of this software is not
responsible for any damages to your 
computer or Java Virtual Machine. 

Permissions
	What you can do:
		* Customize code to fit your needs
		* Distribute software in any form
		* Visit https://sourceforge.net/p/mathquizgame/tickets/
		  to report a problem, or go to the site's forums.
	Please DO NOT:
		* Sell software for your own profits or anybody's
		  profits.
		* Claim ownership of software.

		  If you customize the code and share it, please
		  credit the developer for the starting code.

VERSION LOG
-----------
Version 1.1
	Game fully functional. Includes:
	 * Type in a number for your answer
	 * Press Enter or click the Enter button to input
	 * Type certain commands starting with a forward 
	   slash to control gameplay.